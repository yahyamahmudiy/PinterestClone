package com.example.pinterest.Model

data class Home(var photo:String, var title:String)
